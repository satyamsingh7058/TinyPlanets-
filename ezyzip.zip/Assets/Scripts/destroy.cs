﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class destroy : MonoBehaviour
{
    private GameMaster gm;

    public GameObject collisionEffect;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        collision.enabled = false;
        gm.counterForBoom++;
        if (collision.tag == "Planet")
        {
            if (gm.counterForBoom % 2 == 0 && collisionEffect != null)
            {
                collisionEffect.transform.position = collision.transform.position;
                Instantiate(collisionEffect, collision.transform.position, Quaternion.identity);
            }
            if (collision.name == "mercury")
            {
                collision.GetComponent<CircleCollider2D>().enabled = true;
            }
            gm.GameOver();
            Destroy(gameObject);
        }
    }
}
